# Windows screenshot email through classic Outlook

1. Extract this ZIP to one folder. Open Outlook (classic) and check that you can send from your chosen account.
2. Install x64 Python 3.13 with its Windows launcher. Open PowerShell in the extracted folder and run these two commands.

       py -3.13 -m pip install -r requirements.txt
       py -3.13 capture_email.py --list-windows

3. Open config.ini in Notepad. Paste one complete, unique window title after title =. Enter your Outlook account address after sender = and the destination address after recipients =. Save the file. The default is every 30 minutes. For fixed local times, set mode = daily and edit daily_times.
4. Test one email and check the recipient inbox for the PNG.

       py -3.13 capture_email.py --once

5. Double-click Start screenshot schedule.cmd to run until you press Ctrl+C. Interval mode sends immediately at startup, including after a one-shot test. Keep the PC awake and unlocked, the console running, and the window open and unminimized. If Outlook prompts on every send, the schedule needs that approval on this PC.
