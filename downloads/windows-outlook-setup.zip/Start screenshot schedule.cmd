@echo off
py -3.13 "%~dp0capture_email.py"
if errorlevel 1 pause
